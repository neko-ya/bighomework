#ifndef STARTWIN_H
#define STARTWIN_H

#include <QWidget>

namespace Ui {
class StartWin;
}

class StartWin : public QWidget
{
    Q_OBJECT

public:
    explicit StartWin(QWidget *parent = 0);
    ~StartWin();

private:
    Ui::StartWin *ui;
};

#endif // STARTWIN_H

#include "startwin.h"
#include "ui_startwin.h"
#include "mainwindow.h"

StartWin::StartWin(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::StartWin)
{
    ui->setupUi(this);
    setWindowTitle("Start the game.");

    //round number
    const int Num = 2;
    //button number
    QPushButton* btnarr[Num]={ui->round1, ui->round2};
    for(int i=0;i<Num;i++)
        connect(btnarr[i],&QPushButton::clicked,[=]()//监听所有按钮点击
    {
        MainWindow *mainwindow = new MainWindow(i);//向游戏类中传入对应关卡编号
        mainwindow->show();//显示窗口

    });



}

StartWin::~StartWin()
{
    delete ui;
}

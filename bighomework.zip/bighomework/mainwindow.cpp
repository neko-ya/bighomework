
#include "mainwindow.h"
#include <QDebug>
#include <QPushButton>
#include <QDebug>



MainWindow::MainWindow(int LevelNumber) : LevelNumber(LevelNumber)
{
    //设置固定窗口大小
    setFixedSize(1040, 640);

    //设置标题
    setWindowTitle("游戏界面");
}
